﻿//|Type of element|id|class|style|function in body|function in elementet|

// No #Comments because of time :D .
GenerateFromObjects({
    element: ["div", "div"],
    style: ["height:8em;width:8em;background-color:red;", "height:10em;width:10em;background-color:blue;"]
});

function GenerateFromObjects(obj) {
  for(var a = 0; a < obj.element.length; a++){
    if(obj.element != null && obj.element != "undefined"){
      try{
        var cont = "container"+a;
        cont = document.createElement(obj.element[a]);
      } catch(err) {
        console.log(err);
      }
    }
    if(obj.id != null && obj.id != "undefined"){
      try{
        var id = cont.setAttribute("id", obj.id[a]);
      } catch(err) {
        console.log(err);
      }
    }
    if(obj.classname != null && obj.classname != "undefined"){
      try{
        var className = cont.setAttribute("class", obj.classname[a]);
      } catch(err) {
        console.log(err);
      }
    }
    if(obj.style != null && obj.style != "undefined"){
      try{
        var style = cont.style = obj.style[a];
      } catch(err) {
        console.log(err);
      }
    }
    if(obj.bodyfunc != null && obj.bodyfunc != "undefined"){
      try{
        var scripts = "scripts"+a;
        scripts = document.createElement("script");
        scripts.type = "text/javascript";
        scripts.innerHTML = obj.bodyfunc[a];
        document.body.appendChild(scripts);
      } catch(err) {
        console.log(err);
      }
    }
    if(obj.elementfunc != null && obj.elementfunc != "undefined"){
      try{
        var scripts = "scripts"+a;
        scripts = document.createElement("script");
        scripts.type = "text/javascript";
        scripts.innerHTML = obj.elementfunc[a];
        cont.appendChild(scripts);
      } catch(err) {
        console.log(err);
      }
    }
    document.body.appendChild(cont);
  }
}
// Made By dave95a
